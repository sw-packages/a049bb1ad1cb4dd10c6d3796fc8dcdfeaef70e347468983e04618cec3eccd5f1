/* client.c --- EXTERNAL mechanism as defined in RFC 2222, client side.
 * Copyright (C) 2002-2024 Simon Josefsson
 *
 * This file is part of GNU SASL Library.
 *
 * GNU SASL Library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * GNU SASL Library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GNU SASL Library; if not, write to the Free
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 *
 */

#include <config.h>

/* Get specification. */
#include "external.h"

/* Get strdup, strlen. */
#include <string.h>

int
_gsasl_external_client_step (Gsasl_session *sctx,
			     void *mech_data _GL_UNUSED,
			     const char *input _GL_UNUSED,
			     size_t input_len _GL_UNUSED,
			     char **output, size_t *output_len)
{
  const char *p;

  p = gsasl_property_get (sctx, GSASL_AUTHZID);
  if (!p)
    p = "";

  *output = strdup (p);
  if (!*output)
    return GSASL_MALLOC_ERROR;
  *output_len = strlen (p);

  return GSASL_OK;
}
